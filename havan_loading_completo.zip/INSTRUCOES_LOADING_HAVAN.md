# Loading Animado Havan - Instruções de Uso

## 📋 Descrição do Arquivo

Arquivo GIF animado de **alta qualidade** (200px × 200px) com as cores oficiais da Havan, desenvolvido especificamente para integração no Typebot após verificação de dados.

## 🎬 Características da Animação

### Timeline de 6 Segundos

**Fase 1 (0-3 segundos): Verificação**
- Exibe a letra "H" (logo da Havan) no centro
- Spinner animado girando ao redor da letra
- Mensagem: "Verificando respostas..."
- Cores: Azul marinho (#003d7a) e verde (#00a86b)

**Fase 2 (3-3.5 segundos): Transição**
- Fade out da primeira mensagem
- Fade in da mensagem de sucesso
- Spinner desaparecendo suavemente

**Fase 3 (3.5-6 segundos): Sucesso**
- Checkmark (✓) em verde em círculo destacado
- Mensagem: "Respostas validadas com sucesso!"
- **3 certificados verdes (✓)** abaixo para indicar validação
- Efeito de scale-in e fade-in

### Características Técnicas

✓ **Sem Pixelação**: Renderizado em alta qualidade com 2x DPI  
✓ **Sem Looping**: Fica estático na tela de sucesso após 6 segundos  
✓ **Cores Oficiais Havan**: Azul marinho e verde  
✓ **Certificados Verdes**: 3 checkmarks no final para indicar validação  
✓ **Tamanho Otimizado**: 795 KB (comprimido)  
✓ **Formato**: GIF animado (compatível com todos os navegadores)  

## 📁 Arquivos Inclusos

1. **havan_loading_hq.gif** - O arquivo GIF final (pronto para usar)
2. **havan_loading_hq.html** - Arquivo HTML/CSS/JS (para referência ou customização)
3. **INSTRUCOES_LOADING_HAVAN.md** - Este arquivo com instruções

## 🚀 Como Usar no Typebot

### Opção 1: Upload Direto no Typebot
1. Acesse seu Typebot
2. Após o bloco de verificação de dados, adicione um bloco de **Imagem**
3. Faça upload do arquivo `havan_loading_hq.gif`
4. Configure a duração de exibição para **6 segundos** (ou deixe como padrão)
5. Adicione um bloco de texto com mensagem de confirmação após o loading

### Opção 2: Usar URL Hospedada
Se preferir hospedar em um servidor:
1. Faça upload do `havan_loading_hq.gif` para o PostImages (seu serviço PRO)
2. Copie a URL fornecida
3. No Typebot, adicione um bloco de **Imagem**
4. Cole a URL no campo de imagem
5. Configure a duração para **6 segundos**

## 🎨 Customizações Possíveis

Se precisar fazer ajustes (cores, mensagens, duração), você pode:

1. **Editar o arquivo HTML** (`havan_loading_hq.html`) com qualquer editor de texto
2. Modificar as mensagens nos campos de texto
3. Alterar as cores nos valores HEX (#003d7a, #00a86b, etc.)
4. Ajustar a duração da animação no JavaScript
5. Regenerar o GIF usando o script Python incluído

## 💾 Arquivos de Geração (Referência)

Se precisar regenerar o GIF com customizações:

- **capture_frames_hq.js** - Script Node.js que captura frames do HTML
- **create_gif_hq.py** - Script Python que converte frames em GIF
- **frames_hq/** - Diretório com os 120 frames individuais (PNG)

### Para Regenerar o GIF:
```bash
# 1. Editar o arquivo HTML conforme necessário
# 2. Executar o script Node.js para capturar frames
node capture_frames_hq.js

# 3. Converter frames para GIF
convert -delay 5 -loop 0 -dispose previous -quality 95 -colors 256 frames_hq/frame_*.png havan_loading_hq.gif
```

## 📊 Especificações Técnicas

| Propriedade | Valor |
|---|---|
| Dimensões | 200px × 200px |
| Formato | GIF Animado |
| Duração | 6 segundos |
| FPS | 20 frames por segundo |
| Total de Frames | 120 |
| Tamanho do Arquivo | ~795 KB |
| Qualidade | Alta (sem pixelação) |
| Cores | RGB |
| Looping | Desativado |

## 🎯 Dicas de Uso

1. **Tempo de Exibição**: O loading foi projetado para 6 segundos. Não recomenda-se alterar para menos de 6 segundos, pois a animação não ficará completa.

2. **Posicionamento**: O loading é quadrado (200x200px), então funciona bem centralizado na página.

3. **Fundo**: O GIF já possui fundo branco com gradiente azul ao redor. Funciona bem em qualquer fundo.

4. **Responsividade**: Você pode redimensionar o GIF no Typebot sem perda de qualidade (foi renderizado em 2x DPI).

5. **Compatibilidade**: Funciona em todos os navegadores modernos (Chrome, Firefox, Safari, Edge).

## 🔧 Suporte

Se precisar fazer ajustes ou customizações:
- Edite o arquivo HTML e regenere o GIF
- Ou entre em contato para solicitar modificações específicas

---

**Versão**: 1.0  
**Data**: Dezembro 2024  
**Desenvolvido para**: Typebot + Havan
